import { useState } from 'react';
import { cn } from '@/lib/utils';
import { motion, AnimatePresence } from 'framer-motion';

interface AddCategoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddCategory: (name: string, icon: string) => void;
  onDeleteCategory: (id: string) => void;
  categories: Array<{id: string; name: string}>;
}

export default function AddCategoryModal({ isOpen, onClose, onAddCategory, onDeleteCategory, categories }: AddCategoryModalProps) {
  const [formData, setFormData] = useState({
    name: '',
    icon: 'fa-solid fa-th-large',
    selectedCategoryId: ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  
  // 常用图标选项
  const popularIcons = [
    'fa-solid fa-th-large', 'fa-solid fa-video', 'fa-solid fa-gamepad', 
    'fa-solid fa-shopping-cart', 'fa-solid fa-book', 'fa-solid fa-mobile-alt',
    'fa-solid fa-users', 'fa-solid fa-car', 'fa-solid fa-newspaper',
    'fa-solid fa-plane', 'fa-solid fa-briefcase', 'fa-solid fa-home',
    'fa-solid fa-music', 'fa-solid fa-money-bill', 'fa-solid fa-ticket-alt',
    'fa-solid fa-university', 'fa-solid fa-envelope'
  ];
  
  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.name.trim()) {
      newErrors.name = '分类名称不能为空';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (validateForm()) {
      onAddCategory(formData.name.trim(), formData.icon);
      
      // 重置表单并关闭模态框
      setFormData({
        name: '',
        icon: 'fa-solid fa-th-large'
      });
      onClose();
    }
  };
  
  return (
    <AnimatePresence mode="wait" initial={false}>
      {isOpen && (
        <>
          {/* 背景遮罩 */}
          <motion.div
            className="fixed inset-0 z-40 bg-black/50 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />
          
          {/* 模态框 */}
          <motion.div
            className="fixed left-1/2 top-1/2 z-50 w-full max-w-md -translate-x-1/2 -translate-y-1/2 rounded-2xl bg-white p-6 shadow-2xl dark:bg-gray-800"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            transition={{ type: 'spring', stiffness: 300, damping: 20 }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center mb-4">
               <h2 className="text-xl font-bold text-gray-800 dark:text-white">分类管理</h2>
               <button
                onClick={onClose}
                className="rounded-full p-1 text-gray-500 transition-colors hover:bg-gray-100 hover:text-gray-700 dark:hover:bg-gray-700 dark:hover:text-gray-200"
                aria-label="Close modal"
              >
                <i className="fa-solid fa-times"></i>
              </button>
            </div>
            
             <div className="mb-6 p-4 bg-gray-50 rounded-lg dark:bg-gray-700/50">
               <h3 className="mb-3 text-sm font-medium text-gray-700 dark:text-gray-300">删除分类</h3>
               <div className="flex items-center space-x-3">
                 <select
                   value={formData.selectedCategoryId}
                   onChange={(e) => setFormData({...formData, selectedCategoryId: e.target.value})}
                   className="flex-1 rounded-lg border px-3 py-2 text-gray-800 focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-200 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-200"
                 >
                   <option value="">选择要删除的分类</option>
                   {categories.map(category => (
                     <option key={category.id} value={category.id}>
                       {category.name}
                     </option>
                   ))}
                 </select>
                 <button
                   type="button"
                   disabled={!formData.selectedCategoryId}
                   onClick={() => {
                     const selectedCategory = categories.find(c => c.id === formData.selectedCategoryId);
                     if (selectedCategory && window.confirm(`确定要删除分类 "${selectedCategory.name}" 吗？此操作将删除该分类下的所有网站。`)) {
                       onDeleteCategory(formData.selectedCategoryId);
                       setFormData({...formData, selectedCategoryId: ''});
                     }
                   }}
                   className="rounded-lg bg-red-600 px-4 py-2 text-white transition-colors hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 dark:focus:ring-offset-gray-800 disabled:opacity-50 disabled:cursor-not-allowed"
                 >
                   删除
                 </button>
               </div>
             </div>
             
             <div className="p-4 bg-gray-50 rounded-lg dark:bg-gray-700/50">
               <h3 className="mb-3 text-sm font-medium text-gray-700 dark:text-gray-300">添加新分类</h3>
             <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="mb-1 block text-sm font-medium text-gray-700 dark:text-gray-300">
                  分类名称 <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className={cn(
                    "w-full rounded-lg border px-3 py-2 text-gray-800 focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-200 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-200",
                    errors.name ? "border-red-500 focus:border-red-500 focus:ring-red-200" : "border-gray-300"
                  )}
                  placeholder="输入分类名称"
                />
                {errors.name && (
                  <p className="mt-1 text-xs text-red-500">{errors.name}</p>
                )}
              </div>
              
              <div>
                <label className="mb-2 block text-sm font-medium text-gray-700 dark:text-gray-300">
                  选择图标
                </label>
                <div className="grid grid-cols-6 gap-3">
                  {popularIcons.map((icon, index) => (
                    <button
                      key={index}
                      type="button"
                      onClick={() => setFormData({...formData, icon})}
                      className={cn(
                        "flex flex-col items-center justify-center rounded-lg p-3 transition-all",
                        formData.icon === icon 
                          ? "border-2 border-blue-500 bg-blue-50 dark:border-blue-400 dark:bg-blue-900/30" 
                          : "border border-gray-200 hover:border-gray-300 dark:border-gray-700 dark:hover:border-gray-600"
                      )}
                    >
                      <i className={`${icon} text-2xl`}></i>
                    </button>
                  ))}
                </div>
              </div>
              
              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full rounded-lg bg-blue-600 px-4 py-2 text-white transition-colors hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 dark:focus:ring-offset-gray-800"
                >
                  添加分类
                </button>
              </div>
             </form>
             </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}