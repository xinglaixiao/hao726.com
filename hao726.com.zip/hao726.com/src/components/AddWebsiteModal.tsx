import { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';
import { motion, AnimatePresence } from 'framer-motion';
import { Category, Website } from '@/lib/types';
import { toast } from 'sonner';


interface AddWebsiteModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddWebsite: (website: Omit<Website, 'id'>) => void;
  onDeleteWebsite: (websiteId: string) => void;
  categories: Category[];
}


export default function AddWebsiteModal({ isOpen, onClose, onAddWebsite, onDeleteWebsite, categories }: AddWebsiteModalProps) {
  const [activeTab, setActiveTab] = useState<'add' | 'delete'>('add');
  const [formData, setFormData] = useState({
    name: '',
    url: '',
    category: categories[0]?.id || '',
    selectedWebsiteId: ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  
  // 获取所有网站列表
  const allWebsites = categories.reduce((acc, category) => {
    return [...acc, ...category.websites.map(website => ({
      ...website,
      categoryName: category.name
    }))];
  }, [] as (Website & { categoryName: string })[]);
  
  // 当分类变化时，重置选中的网站
  useEffect(() => {
    setFormData(prev => ({
      ...prev,
      selectedWebsiteId: ''
    }));
  }, [formData.category]);
  
  // 根据选中的分类筛选网站
  const filteredWebsites = formData.category 
    ? allWebsites.filter(website => website.category === formData.category)
    : allWebsites;
  
  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (activeTab === 'add') {
      if (!formData.name.trim()) {
        newErrors.name = '网站名称不能为空';
      }
      
      if (!formData.url.trim()) {
        newErrors.url = '网址不能为空';
      } else if (!/^https?:\/\//i.test(formData.url)) {
        newErrors.url = '请输入有效的网址，以http://或https://开头';
      }
      
      if (!formData.category) {
        newErrors.category = '请选择分类';
      }
    } else {
      if (!formData.category) {
        newErrors.category = '请先选择分类';
      }
      
      if (!formData.selectedWebsiteId) {
        newErrors.selectedWebsiteId = '请选择要删除的网站';
      }
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (validateForm()) {
      if (activeTab === 'add') {
        // 确保URL以http://或https://开头
        const url = formData.url.startsWith('http') 
          ? formData.url 
          : `https://${formData.url}`;
        
        onAddWebsite({
          ...formData,
          url,
          isFavorite: false
        });
        
        // 重置表单
        setFormData(prev => ({
          ...prev,
          name: '',
          url: ''
        }));
        
        toast.success(`已添加网站: ${formData.name}`);
      } else {
        // 删除网站
        const websiteToDelete = allWebsites.find(w => w.id === formData.selectedWebsiteId);
        if (websiteToDelete && window.confirm(`确定要删除网站 "${websiteToDelete.name}" 吗？`)) {
          onDeleteWebsite(formData.selectedWebsiteId);
          setFormData(prev => ({
            ...prev,
            selectedWebsiteId: ''
          }));
          toast.success(`已删除网站: ${websiteToDelete.name}`);
        }
      }
      
      // 只有添加操作后关闭模态框，删除操作保持模态框打开
      if (activeTab === 'add') {
        onClose();
      }
    }
  };
  
  return (
    <AnimatePresence mode="wait" initial={false}>
      {isOpen && (
        <>
          {/* 背景遮罩 */}
          <motion.div
            className="fixed inset-0 z-40 bg-black/50 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />
          
          {/* 模态框 */}
          <motion.div
            className="fixed left-1/2 top-1/2 z-50 w-full max-w-md -translate-x-1/2 -translate-y-1/2 rounded-2xl bg-white p-6 shadow-2xl dark:bg-gray-800"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            transition={{ type: 'spring', stiffness: 300, damping: 20 }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-gray-800 dark:text-white">
                {activeTab === 'add' ? '添加新网站' : '删除网站'}
              </h2>
              <button
                onClick={onClose}
                className="rounded-full p-1 text-gray-500 transition-colors hover:bg-gray-100 hover:text-gray-700 dark:hover:bg-gray-700 dark:hover:text-gray-200"
                aria-label="Close modal"
              >
                <i className="fa-solid fa-times"></i>
              </button>
            </div>
            
            {/* 标签切换 */}
            <div className="mb-6 flex rounded-lg bg-gray-100 p-1 dark:bg-gray-700">
              <button
                type="button"
                onClick={() => setActiveTab('add')}
                className={`flex-1 rounded-md py-2 text-sm font-medium transition-colors ${
                  activeTab === 'add'
                    ? 'bg-white text-blue-600 shadow-sm dark:bg-gray-600 dark:text-blue-400'
                    : 'text-gray-600 hover:bg-gray-200 dark:text-gray-300 dark:hover:bg-gray-600'
                }`}
              >
                <i className="fa-solid fa-plus mr-1"></i> 添加网站
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('delete')}
                className={`flex-1 rounded-md py-2 text-sm font-medium transition-colors ${
                  activeTab === 'delete'
                    ? 'bg-white text-red-600 shadow-sm dark:bg-gray-600 dark:text-red-400'
                    : 'text-gray-600 hover:bg-gray-200 dark:text-gray-300 dark:hover:bg-gray-600'
                }`}
              >
                <i className="fa-solid fa-trash mr-1"></i> 删除网站
              </button>
            </div>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* 分类选择 - 两个标签页都需要 */}
              <div>
                <label className="mb-1 block text-sm font-medium text-gray-700 dark:text-gray-300">
                  分类 <span className="text-red-500">*</span>
                </label>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({...formData, category: e.target.value})}
                  className={cn(
                    "w-full rounded-lg border px-3 py-2 text-gray-800 focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-200 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-200",
                    errors.category ? "border-red-500 focus:border-red-500 focus:ring-red-200" : "border-gray-300"
                  )}
                >
                  {categories.map(category => (
                    <option key={category.id} value={category.id}>
                      {category.name}
                    </option>
                  ))}
                </select>
                {errors.category && (
                  <p className="mt-1 text-xs text-red-500">{errors.category}</p>
                )}
              </div>
              
              {activeTab === 'add' ? (
                // 添加网站表单
                <>
                  <div>
                    <label className="mb-1 block text-sm font-medium text-gray-700 dark:text-gray-300">
                      网站名称 <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                      className={cn(
                        "w-full rounded-lg border px-3 py-2 text-gray-800 focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-200 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-200",
                        errors.name ? "border-red-500 focus:border-red-500 focus:ring-red-200" : "border-gray-300"
                      )}
                      placeholder="输入网站名称"
                    />
                    {errors.name && (
                      <p className="mt-1 text-xs text-red-500">{errors.name}</p>
                    )}
                  </div>
                  
                  <div>
                    <label className="mb-1 block text-sm font-medium text-gray-700 dark:text-gray-300">
                      网址 <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="url"
                      value={formData.url}
                      onChange={(e) => setFormData({...formData, url: e.target.value})}
                      className={cn(
                        "w-full rounded-lg border px-3 py-2 text-gray-800 focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-200 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-200",
                        errors.url ? "border-red-500 focus:border-red-500 focus:ring-red-200" : "border-gray-300"
                      )}
                      placeholder="https://example.com"
                    />
                    {errors.url && (
                      <p className="mt-1 text-xs text-red-500">{errors.url}</p>
                    )}
                  </div>
                </>
              ) : (
                // 删除网站表单
                <div>
                  <label className="mb-1 block text-sm font-medium text-gray-700 dark:text-gray-300">
                    选择网站 <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={formData.selectedWebsiteId}
                    onChange={(e) => setFormData({...formData, selectedWebsiteId: e.target.value})}
                    className={cn(
                      "w-full rounded-lg border px-3 py-2 text-gray-800 focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-200 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-200",
                      errors.selectedWebsiteId ? "border-red-500 focus:border-red-500 focus:ring-red-200" : "border-gray-300"
                    )}
                  >
                    <option value="">选择要删除的网站</option>
                    {filteredWebsites.map(website => (
                      <option key={website.id} value={website.id}>
                        {website.name}
                      </option>
                    ))}
                  </select>
                  {errors.selectedWebsiteId && (
                    <p className="mt-1 text-xs text-red-500">{errors.selectedWebsiteId}</p>
                  )}
                  
                  {formData.selectedWebsiteId && (
                    <div className="mt-4 rounded-lg bg-gray-50 p-3 dark:bg-gray-700/50">
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        <i className="fa-solid fa-info-circle mr-1 text-blue-500"></i>
                        确认删除: <span className="font-medium text-gray-800 dark:text-gray-200">{
                          filteredWebsites.find(w => w.id === formData.selectedWebsiteId)?.name
                        }</span>
                      </p>
                    </div>
                  )}
                </div>
              )}
              
              <div className="pt-2">
                <button
                  type="submit"
                  className={cn(
                    "w-full rounded-lg px-4 py-2 text-white transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 dark:focus:ring-offset-gray-800",
                    activeTab === 'add'
                      ? "bg-blue-600 hover:bg-blue-700 focus:border-blue-500 focus:ring-blue-200"
                      : "bg-red-600 hover:bg-red-700 focus:border-red-500 focus:ring-red-200"
                  )}
                >
                  {activeTab === 'add' ? (
                    <>
                      <i className="fa-solid fa-plus mr-1"></i> 添加网站
                    </>
                  ) : (
                    <>
                      <i className="fa-solid fa-trash mr-1"></i> 删除网站
                    </>
                  )}
                </button>
              </div>
            </form>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}