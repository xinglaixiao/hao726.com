import { Category } from '@/lib/types';
import WebsiteCard from './WebsiteCard';
import { motion } from 'framer-motion';

interface CategorySectionProps {
  category: Category;
  filteredWebsites: Category['websites'];
  onToggleFavorite: (id: string) => void;
  onDeleteWebsite: (websiteId: string) => void;
  onDeleteCategory: (categoryId: string) => void;
}

export default function CategorySection({ 
  category, 
  filteredWebsites, 
  onToggleFavorite,
  onDeleteWebsite,
  onDeleteCategory
}: CategorySectionProps) {
  // Only show the category if there are websites to display
  if (filteredWebsites.length === 0) return null;
  
  return (
    <motion.section
      className="mb-8 scroll-mt-20"
      id={category.id}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.1 }}
    >
       <div className="mb-4 flex items-center justify-between">
         <h2 className="flex items-center text-xl font-semibold text-gray-800 dark:text-gray-200">
           <i className={`mr-2 ${category.icon} text-blue-500`}></i>
           {category.name}
         </h2>
          <div className="flex items-center space-x-2">
             <span className="rounded-full bg-blue-100 px-3 py-1 text-sm font-medium text-blue-600 dark:bg-blue-900 dark:text-blue-300">
               {filteredWebsites.length}
             </span>
           </div>
       </div>
      
      <div className="grid grid-cols-4 gap-3 sm:grid-cols-5 md:grid-cols-6 lg:grid-cols-7 xl:grid-cols-8">
        {filteredWebsites.map((website) => (
           <WebsiteCard
             key={website.id}
             website={website}
             onToggleFavorite={onToggleFavorite}
             onDeleteWebsite={onDeleteWebsite}
           />
        ))}
      </div>
    </motion.section>
  );
}