import { useState } from 'react';
import { cn } from '@/lib/utils';
import { motion } from 'framer-motion';

export default function SearchBar() {
  const [query, setQuery] = useState('');
  
  // 明确设置为百度搜索引擎
  const searchUrl = 'https://www.baidu.com/s?wd=';
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      window.open(`${searchUrl}${encodeURIComponent(query.trim())}`, '_blank');
    }
  };
  
  return (
    <motion.div
      className="relative w-full max-w-2xl"
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <form onSubmit={handleSubmit} className="relative">
        <input
          type="text"
          placeholder="搜索..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
           className={cn(
             'w-full rounded-md border border-gray-300 bg-white px-4 py-2.5 pl-10 text-gray-800 transition-all duration-300 ease-in-out focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-800 dark:text-gray-200'
           )}
           aria-label="搜索"
         />
         
         <div className="absolute left-4 top-1/2 -translate-y-1/2 flex items-center">
           <i className="fa-brands fa-baidu text-blue-500"></i>
         </div>
         
         {query && (
           <button
             type="button"
             onClick={() => setQuery('')}
             className="absolute right-56 top-1/2 -translate-y-1/2 p-1 text-gray-400 transition-colors hover:text-gray-600 dark:hover:text-gray-300"
             aria-label="清除搜索"
           >
             <i className="fa-solid fa-times"></i>
           </button>
         )}
         
         <button
           type="submit"
           className="absolute right-0 top-0 h-full px-4 text-sm font-medium text-white bg-blue-500 transition-colors hover:bg-blue-600"
         >
           百度一下
         </button>
      </form>
    </motion.div>
  );
}