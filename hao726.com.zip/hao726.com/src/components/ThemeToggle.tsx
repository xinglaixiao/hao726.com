import { useTheme } from '@/hooks/useTheme';
import { motion, AnimatePresence } from 'framer-motion';

export default function ThemeToggle() {
  const { theme, toggleTheme, isDark } = useTheme();
  
  return (
    <button
      onClick={toggleTheme}
      className="relative rounded-full p-2 transition-colors hover:bg-gray-100 dark:hover:bg-gray-700"
      aria-label={isDark ? "Switch to light theme" : "Switch to dark theme"}
    >
      <div className="relative h-8 w-14 rounded-full bg-gray-200 transition-colors dark:bg-gray-700">
        <AnimatePresence mode="wait" initial={false}>
          <motion.div
            key={theme}
            className="absolute left-1 top-1 flex h-6 w-6 items-center justify-center rounded-full bg-white shadow-sm transition-transform"
            animate={{
              x: isDark ? 8 : 0,
              backgroundColor: isDark ? "#fbbf24" : "#ffffff"
            }}
            transition={{ type: "spring", stiffness: 300, damping: 20 }}
          >
            {isDark ? (
              <i className="fa-solid fa-sun text-yellow-500"></i>
            ) : (
              <i className="fa-solid fa-moon text-gray-700"></i>
            )}
          </motion.div>
        </AnimatePresence>
      </div>
    </button>
  );
}