import { useState } from 'react';
import { Website } from '@/lib/types';
import { cn } from '@/lib/utils';
import { motion } from 'framer-motion';

interface WebsiteCardProps {
  website: Website;
  onToggleFavorite: (id: string) => void;
  onDeleteWebsite: (id: string) => void;
}

export default function WebsiteCard({ website, onToggleFavorite, onDeleteWebsite }: WebsiteCardProps) {
  const [isHovered, setIsHovered] = useState(false);

  const handleClick = (e: React.MouseEvent) => {
    e.preventDefault();
    window.open(website.url, '_blank');
  };

  return (
    <motion.div
      className={cn(
        'group relative flex flex-col items-center justify-center rounded-xl p-4 transition-all duration-300 ease-in-out bg-white dark:bg-gray-800 shadow-md hover:shadow-lg',
        isHovered ? 'scale-105' : 'scale-100'
      )}
      onClick={handleClick}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      whileHover={{ y: -5 }}
      transition={{ type: 'spring', stiffness: 300, damping: 10 }}
    >

      
       <h3 className="mt-3 text-center font-medium text-gray-800 dark:text-gray-200">{website.name}</h3>
       
       <div className="absolute top-2 right-2 flex space-x-1">
         <button
           className={cn(
             'rounded-full p-1 transition-colors',
             website.isFavorite 
               ? 'text-yellow-400 hover:text-yellow-500' 
               : 'text-gray-400 hover:text-yellow-400 dark:text-gray-500'
           )}
           onClick={(e) => {
             e.stopPropagation();
             onToggleFavorite(website.id);
           }}
           aria-label={website.isFavorite ? "Remove from favorites" : "Add to favorites"}
         >
           <i className={cn(
             'fa-heart',
             website.isFavorite ? 'fa-solid' : 'fa-regular'
           )}></i>
         </button>
         

       </div>
      
      <div className={cn(
        'absolute bottom-0 left-0 right-0 h-1 bg-blue-500 transition-all duration-300 ease-in-out',
        isHovered ? 'translate-x-0' : '-translate-x-full'
      )}></div>
    </motion.div>
  );
}