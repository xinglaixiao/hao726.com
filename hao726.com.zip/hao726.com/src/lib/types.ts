export interface Website {
  id: string;
  name: string;
  url: string;

  category: string;
  isFavorite: boolean;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  websites: Website[];
}

export interface FriendshipLink {
  id: string;
  name: string;
  url: string;
}