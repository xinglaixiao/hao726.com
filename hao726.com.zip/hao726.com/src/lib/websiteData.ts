import { Category, FriendshipLink } from './types';

export const categories: Category[] = [
  {
    id: 'video',
    name: '视频',
    icon: 'fa-solid fa-video',
    websites: [
      { id: 'haokan', name: '好看视频', url: 'https://haokan.baidu.com', category: 'video', isFavorite: false },
      { id: 'iqiyi', name: '爱奇艺高清', url: 'https://www.iqiyi.com', category: 'video', isFavorite: false },
      { id: 'tencent-video', name: '腾讯视频', url: 'https://v.qq.com', category: 'video', isFavorite: false },
      { id: 'baidu-live', name: '百度直播', url: 'https://live.baidu.com', category: 'video', isFavorite: false },
      { id: 'youku', name: '优酷网', url: 'https://www.youku.com', category: 'video', isFavorite: false },
      { id: 'mgtv', name: '芒果TV', url: 'https://www.mgtv.com', category: 'video', isFavorite: false },
      { id: 'sohu-video', name: '搜狐视频', url: 'https://tv.sohu.com', category: 'video', isFavorite: false },
      { id: 'migu-video', name: '咪咕视频', url: 'https://www.miguvideo.com', category: 'video', isFavorite: false },
      { id: 'ai-video', name: 'AI视频', url: 'https://ai-video.com', category: 'video', isFavorite: false },
      { id: 'cctv', name: '央视网', url: 'https://www.cctv.com', category: 'video', isFavorite: false }
    ]
  },
  {
    id: 'comprehensive',
    name: '综合',
    icon: 'fa-solid fa-th-large',
    websites: [
      { id: 'gaodun-edu', name: '高顿教育', url: 'https://www.gaodun.com', category: 'comprehensive', isFavorite: false },
      { id: 'dejie-electronics', name: '得捷电子', url: 'https://www.digikey.com.cn', category: 'comprehensive', isFavorite: false },
      { id: 'accounting', name: '会计网', url: 'https://www.kuaiji.com', category: 'comprehensive', isFavorite: false },
      { id: 'baidu-baike', name: '百度百科', url: 'https://baike.baidu.com', category: 'comprehensive', isFavorite: false },
      { id: 'wechat-center', name: '微信中心', url: 'https://weixin.qq.com', category: 'comprehensive', isFavorite: false },
      { id: '163-open', name: '网易公开课', url: 'https://open.163.com', category: 'comprehensive', isFavorite: false },
      { id: 'docin', name: '豆丁网', url: 'https://www.docin.com', category: 'comprehensive', isFavorite: false },
      { id: 'zxxk', name: '学科网', url: 'https://www.zxxk.com', category: 'comprehensive', isFavorite: false },
      { id: 'education-exam', name: '教育考试', url: 'https://www.neea.edu.cn', category: 'comprehensive', isFavorite: false },
      { id: 'baidu-marketing', name: '百度营销', url: 'https://e.baidu.com', category: 'comprehensive', isFavorite: false }
    ]
  },
  {
    id: 'game',
    name: '游戏',
    icon: 'fa-solid fa-gamepad',
    websites: [
      { id: 'baidu-game', name: '百度游戏', url: 'https://game.baidu.com', category: 'game', isFavorite: false },
      { id: '37-game', name: '37网游', url: 'https://www.37.com', category: 'game', isFavorite: false },
      { id: '9377-game', name: '9377页游', url: 'https://www.9377.com', category: 'game', isFavorite: false },
      { id: '4366-game', name: '4366页游', url: 'https://www.4366.com', category: 'game', isFavorite: false },
      { id: 'youxi-minsheng', name: '游民星空', url: 'https://www.gamersky.com', category: 'game', isFavorite: false },
      { id: 'hao123-game', name: 'hao123游戏', url: 'https://game.hao123.com', category: 'game', isFavorite: false },
      { id: '17173', name: '17173', url: 'https://www.17173.com', category: 'game', isFavorite: false },
      { id: '3d-game', name: '3D游戏', url: 'https://www.3dmgame.com', category: 'game', isFavorite: false },
      { id: '4399-game', name: '4399游戏', url: 'https://www.4399.com', category: 'game', isFavorite: false },
      { id: 'ali213', name: '游侠网', url: 'https://www.ali213.net', category: 'game', isFavorite: false }
    ]
  },
  {
    id: 'webgame',
    name: '页游',
    icon: 'fa-solid fa-browser',
    websites: [
      { id: '2025-legend', name: '2025传奇', url: 'https://2025-legend.com', category: 'webgame', isFavorite: false },
      { id: '1.76-legend', name: '1.76传奇', url: 'https://1.76.com', category: 'webgame', isFavorite: false },
      { id: 'chaos-legend', name: '超变传奇', url: 'https://chaos-legend.com', category: 'webgame', isFavorite: false },
      { id: 'kaitian-xiyou', name: '开天西游', url: 'https://kaitian-xiyou.com', category: 'webgame', isFavorite: false },
      { id: 'shanhai-zhiyi', name: '山海志异', url: 'https://shanhai-zhiyi.com', category: 'webgame', isFavorite: false },
      { id: 'qiankun-tiandi', name: '乾坤天地', url: 'https://qiankun-tiandi.com', category: 'webgame', isFavorite: false },
      { id: 'julong-shouzhu', name: '巨龙猎手', url: 'https://julong-shouzhu.com', category: 'webgame', isFavorite: false },
      { id: 'rexue-zhanji', name: '热血战纪', url: 'https://rexue-zhanji.com', category: 'webgame', isFavorite: false },
      { id: 'chuanqi-shengshi2', name: '传奇盛世2', url: 'https://chuanqi-shengshi2.com', category: 'webgame', isFavorite: false },
      { id: 'yuanshi-chuanqi', name: '原始传奇', url: 'https://yuanshi-chuanqi.com', category: 'webgame', isFavorite: false }
    ]
  },
  {
    id: 'shopping',
    name: '购物',
    icon: 'fa-solid fa-shopping-cart',
    websites: [
      { id: 'aitaobao', name: '爱淘宝', url: 'https://ai.taobao.com', category: 'shopping', isFavorite: false },
      { id: 'dangdang', name: '当当网', url: 'https://www.dangdang.com', category: 'shopping', isFavorite: false },
      { id: 'taobao-tehui', name: '淘宝特卖', url: 'https://tehui.taobao.com', category: 'shopping', isFavorite: false },
      { id: 'tmall', name: '天猫', url: 'https://www.tmall.com', category: 'shopping', isFavorite: false },
      { id: 'tmall-global', name: '天猫国际', url: 'https://www.tmall.hk', category: 'shopping', isFavorite: false },
      { id: 'jd', name: '京东商城', url: 'https://www.jd.com', category: 'shopping', isFavorite: false },
      { id: 'jd-home', name: '京东家居', url: 'https://home.jd.com', category: 'shopping', isFavorite: false },
      { id: 'smzdm', name: '什么值得买', url: 'https://www.smzdm.com', category: 'shopping', isFavorite: false },
      { id: 'taobao', name: '淘宝网', url: 'https://www.taobao.com', category: 'shopping', isFavorite: false },
      { id: '1688', name: '1688', url: 'https://www.1688.com', category: 'shopping', isFavorite: false }
    ]
  },
  {
    id: 'new-game',
    name: '新游',
    icon: 'fa-solid fa-rocket',
    websites: [
      { id: 'menghui-jianghu', name: '梦回江湖', url: 'https://menghui-jianghu.com', category: 'new-game', isFavorite: false },
      { id: 'chuanqi-suiyue', name: '传奇岁月', url: 'https://chuanqi-suiyue.com', category: 'new-game', isFavorite: false },
      { id: 'qingtian-zhinu', name: '雷霆之怒', url: 'https://qingtian-zhinu.com', category: 'new-game', isFavorite: false },
      { id: 'fanren-shenshenzhuan', name: '凡人神将传', url: 'https://fanren-shenshenzhuan.com', category: 'new-game', isFavorite: false },
      { id: 'lingqi-chuanyao', name: '灵奇奇缘', url: 'https://lingqi-chuanyao.com', category: 'new-game', isFavorite: false },
      { id: 'qingyunjue', name: '青云诀', url: 'https://qingyunjue.com', category: 'new-game', isFavorite: false },
      { id: 'xuanying', name: '玄影', url: 'https://xuanying.com', category: 'new-game', isFavorite: false },
      { id: 'sandaren-dajin', name: '散人打金服', url: 'https://sandaren-dajin.com', category: 'new-game', isFavorite: false },
      { id: 'wangzhe-longye', name: '帝王霸业', url: 'https://wangzhe-longye.com', category: 'new-game', isFavorite: false },
      { id: 'shacheng-gaoban', name: '沙城高爆版', url: 'https://shacheng-gaoban.com', category: 'new-game', isFavorite: false }
    ]
  },
  {
    id: 'sports',
    name: '体育',
    icon: 'fa-solid fa-futbol',
    websites: [
      { id: 'sina-sports', name: '新浪体育', url: 'https://sports.sina.com.cn', category: 'sports', isFavorite: false },
      { id: 'hupu-sports', name: '虎扑体育', url: 'https://www.hupu.com', category: 'sports', isFavorite: false },
      { id: 'sohu-sports', name: '搜狐体育', url: 'https://sports.sohu.com', category: 'sports', isFavorite: false },
      { id: 'tencent-sports', name: '腾讯体育', url: 'https://sports.qq.com', category: 'sports', isFavorite: false },
      { id: 'cctv5', name: 'CCTV5', url: 'https://tv.cctv.com/cctv5', category: 'sports', isFavorite: false },
      { id: '163-sports', name: '网易体育', url: 'https://sports.163.com', category: 'sports', isFavorite: false },
      { id: 'pp-sports', name: 'PP体育', url: 'https://www.ppsport.com', category: 'sports', isFavorite: false },
      { id: 'feng凰-sports', name: '凤凰体育', url: 'https://sports.ifeng.com', category: 'sports', isFavorite: false },
      { id: 'aiqiyi-sports', name: '爱奇艺体育', url: 'https://sports.iqiyi.com', category: 'sports', isFavorite: false },
      { id: 'sports-hot', name: '体育热点', url: 'https://sports-hot.com', category: 'sports', isFavorite: false }
    ]
  },
  {
    id: 'novels',
    name: '小说',
    icon: 'fa-solid fa-book',
    websites: [
      { id: 'qidian', name: '起点中文网', url: 'https://www.qidian.com', category: 'novels', isFavorite: false },
      { id: 'qq-reading', name: 'QQ阅读', url: 'https://yuedu.qq.com', category: 'novels', isFavorite: false },
      { id: 'manhuaju', name: '潇湘书院', url: 'https://www.xxsy.net', category: 'novels', isFavorite: false },
      { id: 'jinjiang', name: '晋江文学城', url: 'https://www.jjwxc.net', category: 'novels', isFavorite: false },
      { id: 'zongheng', name: '纵横中文网', url: 'https://www.zongheng.com', category: 'novels', isFavorite: false },
      { id: 'qise', name: '七猫中文网', url: 'https://www.qimao.com', category: 'novels', isFavorite: false },
      { id: 'read-novel', name: '小说阅读', url: 'https://www.readnovel.com', category: 'novels', isFavorite: false },
      { id: 'novel-ranking', name: '小说排行', url: 'https://novel-ranking.com', category: 'novels', isFavorite: false },
      { id: 'fanqie', name: '番茄小说', url: 'https://fanqienovel.com', category: 'novels', isFavorite: false },
      { id: 'wechat-reading', name: '微信读书', url: 'https://weread.qq.com', category: 'novels', isFavorite: false }
    ]
  },
  {
    id: 'mobile',
    name: '手机',
    icon: 'fa-solid fa-mobile-alt',
    websites: [
      { id: 'zol', name: '中关村在线', url: 'https://www.zol.com.cn', category: 'mobile', isFavorite: false },
      { id: 'ithome', name: 'IT之家', url: 'https://www.ithome.com', category: 'mobile', isFavorite: false },
      { id: 'pconline-mobile', name: '太平洋手机', url: 'https://mobile.pconline.com.cn', category: 'mobile', isFavorite: false },
      { id: 'china-mobile', name: '中国移动', url: 'https://www.10086.cn', category: 'mobile', isFavorite: false },
      { id: 'huawei', name: '华为官网', url: 'https://www.huawei.com', category: 'mobile', isFavorite: false },
      { id: 'xiaomi', name: '小米官网', url: 'https://www.mi.com', category: 'mobile', isFavorite: false },
      { id: 'vivo', name: 'vivo手机', url: 'https://www.vivo.com', category: 'mobile', isFavorite: false },
      { id: 'huajun', name: '华军软件园', url: 'https://www.onlinedown.net', category: 'mobile', isFavorite: false },
      { id: 'apple', name: '苹果手机', url: 'https://www.apple.com.cn', category: 'mobile', isFavorite: false },
      { id: 'baidu-shouji', name: '百度手机助手', url: 'https://shouji.baidu.com', category: 'mobile', isFavorite: false }
    ]
  },
  {
    id: 'social',
    name: '社交',
    icon: 'fa-solid fa-users',
    websites: [
      { id: 'douyu', name: '斗鱼TV', url: 'https://www.douyu.com', category: 'social', isFavorite: false },
      { id: 'zhihu', name: '知乎', url: 'https://www.zhihu.com', category: 'social', isFavorite: false },
      { id: 'qq-space', name: 'QQ空间', url: 'https://qzone.qq.com', category: 'social', isFavorite: false },
      { id: 'csdn', name: 'CSDN社区', url: 'https://www.csdn.net', category: 'social', isFavorite: false },
      { id: 'weibo-new', name: '新浪微博', url: 'https://weibo.com', category: 'social', isFavorite: false },
      { id: 'baihe', name: '百合网', url: 'https://www.baihe.com', category: 'social', isFavorite: false },
      { id: 'zhenai', name: '珍爱网', url: 'https://www.zhenai.com', category: 'social', isFavorite: false },
      { id: 'hupu-bbs', name: '虎扑社区', url: 'https://bbs.hupu.com', category: 'social', isFavorite: false },
      { id: 'baidu-tieba', name: '百度贴吧', url: 'https://tieba.baidu.com', category: 'social', isFavorite: false },
      { id: 'renren', name: '人人网', url: 'https://www.renren.com', category: 'social', isFavorite: false }
    ]
  },
  {
    id: 'auto',
    name: '汽车',
    icon: 'fa-solid fa-car',
    websites: [
      { id: 'autohome', name: '汽车之家', url: 'https://www.autohome.com.cn', category: 'auto', isFavorite: false },
      { id: 'baidu-che', name: '百度有驾', url: 'https://youjia.baidu.com', category: 'auto', isFavorite: false },
      { id: 'pcauto', name: '太平洋汽车', url: 'https://www.pcauto.com.cn', category: 'auto', isFavorite: false },
      { id: 'yiche', name: '易车网', url: 'https://www.yiche.com', category: 'auto', isFavorite: false },
      { id: 'autoquan', name: '汽车大全', url: 'https://www.qichedaquan.com', category: 'auto', isFavorite: false },
      { id: 'xcar', name: '爱卡汽车', url: 'https://www.xcar.com.cn', category: 'auto', isFavorite: false },
      { id: 'sina-auto', name: '新浪汽车', url: 'https://auto.sina.com.cn', category: 'auto', isFavorite: false },
      { id: 'sohu-auto', name: '搜狐汽车', url: 'https://auto.sohu.com', category: 'auto', isFavorite: false },
      { id: 'ifeng-auto', name: '凤凰汽车', url: 'https://auto.ifeng.com', category: 'auto', isFavorite: false },
      { id: 'tencent-auto', name: '腾讯汽车', url: 'https://auto.qq.com', category: 'auto', isFavorite: false }
    ]
  },
  {
    id: 'news',
    name: '新闻',
    icon: 'fa-solid fa-newspaper',
    websites: [
      { id: 'sina-news', name: '新浪新闻', url: 'https://news.sina.com.cn', category: 'news', isFavorite: false },
      { id: 'guanchazhe', name: '观察者网', url: 'https://www.guancha.cn', category: 'news', isFavorite: false },
      { id: 'huanqiu', name: '环球网', url: 'https://www.huanqiu.com', category: 'news', isFavorite: false },
      { id: 'cankaoxiaoxi', name: '参考消息', url: 'https://www.cankaoxiaoxi.com', category: 'news', isFavorite: false },
      { id: 'china-news', name: '中国新闻网', url: 'https://www.chinanews.com', category: 'news', isFavorite: false },
      { id: 'sohu-news', name: '搜狐新闻', url: 'https://news.sohu.com', category: 'news', isFavorite: false },
      { id: 'ifeng-military', name: '凤凰军事', url: 'https://mil.ifeng.com', category: 'news', isFavorite: false },
      { id: 'tencent-news', name: '腾讯新闻', url: 'https://news.qq.com', category: 'news', isFavorite: false },
      { id: '163-news', name: '网易新闻', url: 'https://news.163.com', category: 'news', isFavorite: false },
      { id: 'hao123-news', name: 'hao123推荐', url: 'https://tuijian.hao123.com', category: 'news', isFavorite: false }
    ]
  },
  {
    id: 'travel',
    name: '旅游',
    icon: 'fa-solid fa-plane',
    websites: [
      { id: 'ctrip', name: '携程网', url: 'https://www.ctrip.com', category: 'travel', isFavorite: false },
      { id: '12306', name: '12306', url: 'https://www.12306.cn', category: 'travel', isFavorite: false },
      { id: 'mafengwo', name: '马蜂窝', url: 'https://www.mafengwo.cn', category: 'travel', isFavorite: false },
      { id: 'fliggy', name: '飞猪旅行', url: 'https://www.fliggy.com', category: 'travel', isFavorite: false },
      { id: 'tuniu', name: '途牛', url: 'https://www.tuniu.com', category: 'travel', isFavorite: false },
      { id: 'elong', name: '艺龙旅行网', url: 'https://www.elong.com', category: 'travel', isFavorite: false },
      { id: 'qyer', name: '穷游网', url: 'https://www.qyer.com', category: 'travel', isFavorite: false },
      { id: '17u', name: '同程旅行', url: 'https://www.17u.cn', category: 'travel', isFavorite: false },
      { id: 'csair', name: '南方航空', url: 'https://www.csair.com/cn', category: 'travel', isFavorite: false },
      { id: 'hao123-travel', name: 'hao123旅游', url: 'https://travel.hao123.com', category: 'travel', isFavorite: false }
    ]
  },
  {
    id: 'job',
    name: '招聘',
    icon: 'fa-solid fa-briefcase',
    websites: [
      { id: '51job', name: '前程无忧', url: 'https://www.51job.com', category: 'job', isFavorite: false },
      { id: 'boss', name: 'BOSS直聘', url: 'https://www.zhipin.com', category: 'job', isFavorite: false },
      { id: 'liepin', name: '猎聘', url: 'https://www.liepin.com', category: 'job', isFavorite: false },
      { id: 'yingjiesheng', name: '应届生求职', url: 'https://www.yingjiesheng.com', category: 'job', isFavorite: false },
      { id: 'lagou', name: '拉勾', url: 'https://www.lagou.com', category: 'job', isFavorite: false },
      { id: 'gonggong-zhaopin', name: '中国公共招聘', url: 'https://job.mohrss.gov.cn', category: 'job', isFavorite: false },
      { id: 'zhaopin', name: '中华英才', url: 'https://www.chinahr.com', category: 'job', isFavorite: false },
      { id: 'shixiseng', name: '实习僧', url: 'https://www.shixiseng.com', category: 'job', isFavorite: false },
      { id: 'kanzhun', name: '看准网', url: 'https://www.kanzhun.com', category: 'job', isFavorite: false },
      { id: 'weisheng-job', name: '卫生人才网', url: 'https://www.21wecan.com', category: 'job', isFavorite: false }
    ]
  },
  {
    id: 'life',
    name: '生活',
    icon: 'fa-solid fa-home',
    websites: [
      { id: 'fang-com', name: '房天下', url: 'https://www.fang.com', category: 'life', isFavorite: false },
      { id: 'anjuke', name: '安居客', url: 'https://www.anjuke.com', category: 'life', isFavorite: false },
      { id: 'lianjia', name: '链家网', url: 'https://www.lianjia.com', category: 'life', isFavorite: false },
      { id: 'ganji', name: '赶集网', url: 'https://www.ganji.com', category: 'life', isFavorite: false },
      { id: 'aiqicha', name: '爱企查', url: 'https://aiqicha.baidu.com', category: 'life', isFavorite: false },
      { id: 'xiachufang', name: '下厨房', url: 'https://www.xiachufang.com', category: 'life', isFavorite: false },
      { id: 'baixing', name: '百姓网', url: 'https://www.baixing.com', category: 'life', isFavorite: false },
      { id: 'dianping', name: '大众点评', url: 'https://www.dianping.com', category: 'life', isFavorite: false },
      { id: 'meituan', name: '美团网', url: 'https://www.meituan.com', category: 'life', isFavorite: false },
      { id: 'tianyancha', name: '天眼查', url: 'https://www.tianyancha.com', category: 'life', isFavorite: false }
    ]
  },
  {
    id: 'music',
    name: '音乐',
    icon: 'fa-solid fa-music',
    websites: [
      { id: 'kugou', name: '酷狗音乐', url: 'https://www.kugou.com', category: 'music', isFavorite: false },
      { id: '163-music', name: '网易云音乐', url: 'https://music.163.com', category: 'music', isFavorite: false },
      { id: 'kuwo', name: '酷我音乐', url: 'https://www.kuwo.cn', category: 'music', isFavorite: false },
      { id: 'qq-music', name: 'QQ音乐', url: 'https://y.qq.com', category: 'music', isFavorite: false },
      { id: 'qianqian', name: '千千音乐', url: 'https://music.taihe.com', category: 'music', isFavorite: false },
      { id: '5sing', name: '5sing', url: 'https://5sing.kugou.com', category: 'music', isFavorite: false },
      { id: 'qingfeng-dj', name: '清风DJ音乐', url: 'https://www.qingfengdj.com', category: 'music', isFavorite: false },
      { id: 'migu-music', name: '咪咕音乐', url: 'https://music.migu.cn', category: 'music', isFavorite: false },
      { id: 'douban-music', name: '豆瓣音乐', url: 'https://music.douban.com', category: 'music', isFavorite: false },
      { id: 'changba', name: '唱吧', url: 'https://changba.com', category: 'music', isFavorite: false }
    ]
  },
  {
    id: 'finance',
    name: '财经',
    icon: 'fa-solid fa-money-bill',
    websites: [
      { id: 'eastmoney', name: '东方财富', url: 'https://www.eastmoney.com', category: 'finance', isFavorite: false },
      { id: 'sina-finance', name: '新浪财经', url: 'https://finance.sina.com.cn', category: 'finance', isFavorite: false },
      { id: 'stockstar', name: '证券之星', url: 'https://www.stockstar.com', category: 'finance', isFavorite: false },
      { id: 'cnfol', name: '中金在线', url: 'https://www.cnfol.com', category: 'finance', isFavorite: false },
      { id: 'tonghuashun', name: '同花顺', url: 'https://www.10jqka.com.cn', category: 'finance', isFavorite: false },
      { id: 'jrj', name: '金融界', url: 'https://www.jrj.com.cn', category: 'finance', isFavorite: false },
      { id: 'yicai', name: '第一财经', url: 'https://www.yicai.com', category: 'finance', isFavorite: false },
      { id: 'hexun', name: '和讯网', url: 'https://www.hexun.com', category: 'finance', isFavorite: false },
      { id: '163-finance', name: '网易财经', url: 'https://money.163.com', category: 'finance', isFavorite: false },
      { id: 'xueqiu', name: '雪球', url: 'https://xueqiu.com', category: 'finance', isFavorite: false }
    ]
  },
  {
    id: 'lottery',
    name: '彩票',
    icon: 'fa-solid fa-ticket-alt',
    websites: [
      { id: 'zhcw', name: '中国体彩', url: 'https://www.lottery.gov.cn', category: 'lottery', isFavorite: false },
      { id: 'cwl', name: '中国福彩', url: 'https://www.cwl.gov.cn', category: 'lottery', isFavorite: false },
      { id: 'sina-lottery', name: '新浪彩票', url: 'https://lottery.sina.com.cn', category: 'lottery', isFavorite: false },
      { id: 'kuangcai', name: '竞彩网', url: 'https://www.sporttery.cn', category: 'lottery', isFavorite: false },
      { id: 'ssq', name: '双色球', url: 'https://www.cwl.gov.cn/ssq/', category: 'lottery', isFavorite: false },
      { id: 'national-lottery', name: '全国开奖', url: 'https://www.lottery.gov.cn/kj/', category: 'lottery', isFavorite: false },
      { id: 'sohu-lottery', name: '搜狐彩票', url: 'https://caipiao.sohu.com', category: 'lottery', isFavorite: false },
      { id: 'fucai3d', name: '福彩3D', url: 'https://www.cwl.gov.cn/3d/', category: 'lottery', isFavorite: false },
      { id: 'zhongcai', name: '中彩网', url: 'https://www.zhcw.com', category: 'lottery', isFavorite: false },
      { id: 'daletou', name: '大乐透', url: 'https://www.cwl.gov.cn/dlt/', category: 'lottery', isFavorite: false }
    ]
  },
  {
    id: 'bank',
    name: '银行',
    icon: 'fa-solid fa-university',
    websites: [
      { id: 'ccb', name: '建设银行', url: 'https://www.ccb.com', category: 'bank', isFavorite: false },
      { id: 'icbc', name: '中国银行', url: 'https://www.boc.cn', category: 'bank', isFavorite: false },
      { id: 'abc', name: '工商银行', url: 'https://www.icbc.com.cn', category: 'bank', isFavorite: false },
      { id: 'agricultural', name: '农业银行', url: 'https://www.abchina.com', category: 'bank', isFavorite: false },
      { id: 'comm', name: '交通银行', url: 'https://www.bankcomm.com', category: 'bank', isFavorite: false },
      { id: 'cmb', name: '招商银行', url: 'https://www.cmbchina.com', category: 'bank', isFavorite: false },
      { id: 'cib', name: '兴业银行', url: 'https://www.cib.com.cn', category: 'bank', isFavorite: false },
      { id: 'spdb', name: '浦发银行', url: 'https://www.spdb.com.cn', category: 'bank', isFavorite: false },
      { id: 'psbc', name: '邮政储蓄', url: 'https://www.psbc.com', category: 'bank', isFavorite: false },
      { id: 'people-bank', name: '人民银行', url: 'https://www.pbc.gov.cn', category: 'bank', isFavorite: false }
    ]
  },
  {
    id: 'email',
    name: '邮箱',
    icon: 'fa-solid fa-envelope',
    websites: [
      { id: '163mail', name: '163邮箱', url: 'https://mail.163.com', category: 'email', isFavorite: false },
      { id: '126mail', name: '126邮箱', url: 'https://mail.126.com', category: 'email', isFavorite: false },
      { id: 'qqmail', name: 'QQ邮箱', url: 'https://mail.qq.com', category: 'email', isFavorite: false },
      { id: 'sina-mail', name: '新浪邮箱', url: 'https://mail.sina.com.cn', category: 'email', isFavorite: false },
      { id: 'ali-mail', name: '阿里邮箱', url: 'https://mail.aliyun.com', category: 'email', isFavorite: false },
      { id: '139mail', name: '139邮箱', url: 'https://mail.10086.cn', category: 'email', isFavorite: false },
      { id: 'outlook', name: 'Outlook邮箱', url: 'https://outlook.live.com', category: 'email', isFavorite: false },
      { id: 'sohu-mail', name: '搜狐邮箱', url: 'https://mail.sohu.com', category: 'email', isFavorite: false },
      { id: 'baidu-disk', name: '百度网盘', url: 'https://pan.baidu.com', category: 'email', isFavorite: false },
      { id: 'foxmail', name: 'foxmail邮箱', url: 'https://www.foxmail.com', category: 'email', isFavorite: false }
    ]
  }
];

export const friendshipLinks: FriendshipLink[] = [
  { id: 'link1', name: '百度', url: 'https://www.baidu.com' },
  { id: 'link2', name: '谷歌', url: 'https://www.google.com' },
  { id: 'link3', name: '必应', url: 'https://www.bing.com' }
];