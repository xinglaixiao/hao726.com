import { useState, useEffect } from 'react';
import { categories as initialCategories } from '@/lib/websiteData';
import { Category, Website } from '@/lib/types';
import SearchBar from '@/components/SearchBar';
import CategorySection from '@/components/CategorySection';
import ThemeToggle from '@/components/ThemeToggle';
import AddWebsiteModal from '@/components/AddWebsiteModal';
import { motion, AnimatePresence } from 'framer-motion';
import { useTheme } from '@/hooks/useTheme';
import { toast } from 'sonner';
import AddCategoryModal from '@/components/AddCategoryModal';
import { FriendshipLink } from '@/lib/types';
import { friendshipLinks as initialFriendshipLinks } from '@/lib/websiteData';

export default function Home() {
  const [categories, setCategories] = useState<Category[]>(initialCategories);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isAddCategoryModalOpen, setIsAddCategoryModalOpen] = useState(false);
  const { isDark } = useTheme();
  const [friendshipLinks, setFriendshipLinks] = useState<FriendshipLink[]>(initialFriendshipLinks);
  const [newLinkName, setNewLinkName] = useState('');
  const [newLinkUrl, setNewLinkUrl] = useState('');
  const [isAddLinkModalOpen, setIsAddLinkModalOpen] = useState(false);
  const [activeLinkTab, setActiveLinkTab] = useState<'add' | 'delete'>('add');
  const [selectedLinkId, setSelectedLinkId] = useState('');
  
  // 从本地存储加载数据
  useEffect(() => {
    const savedCategories = localStorage.getItem('websiteCategories');
    if (savedCategories) {
      try {
        setCategories(JSON.parse(savedCategories));
      } catch (error) {
        console.error('Failed to parse saved categories', error);
        toast.error('加载保存的数据失败，使用默认数据');
      }
    }
  }, []);
  
  // 保存数据到本地存储
  useEffect(() => {
    localStorage.setItem('websiteCategories', JSON.stringify(categories));
  }, [categories]);
  
  // 从本地存储加载友情链接
  useEffect(() => {
    const savedLinks = localStorage.getItem('friendshipLinks');
    if (savedLinks) {
      try {
        setFriendshipLinks(JSON.parse(savedLinks));
      } catch (error) {
        console.error('Failed to parse saved friendship links', error);
      }
    }
  }, []);
  
  // 保存友情链接到本地存储
  useEffect(() => {
    localStorage.setItem('friendshipLinks', JSON.stringify(friendshipLinks));
  }, [friendshipLinks]);
  
  // 切换收藏状态
  const handleToggleFavorite = (websiteId: string) => {
    setCategories(prevCategories => 
      prevCategories.map(category => ({
        ...category,
        websites: category.websites.map(website => 
          website.id === websiteId 
            ? { ...website, isFavorite: !website.isFavorite } 
            : website
        )
      }))
    );
    toast.success('收藏状态已更新');
  };
  
  // 添加新网站
  const handleAddWebsite = (newWebsite: Omit<Website, 'id'>) => {
    const websiteWithId = {
      ...newWebsite,
      id: `custom-${Date.now()}`
    };
    
    setCategories(prevCategories => 
      prevCategories.map(category => 
        category.id === newWebsite.category
          ? {
              ...category,
              websites: [...category.websites, websiteWithId]
            }
          : category
      )
    );
    
    setIsAddModalOpen(false);
   toast.success(`已添加网站: ${newWebsite.name}`);
  };
  
  // 删除网站
  const handleDeleteWebsite = (websiteId: string) => {
    setCategories(prevCategories => 
      prevCategories.map(category => ({
        ...category,
        websites: category.websites.filter(website => website.id !== websiteId)
      }))
    );
    toast.success('网站已删除');
  };
  
  // 添加分类
  const handleAddCategory = (name: string, icon: string) => {
    const newCategoryId = name.toLowerCase().replace(/\s+/g, '-') + '-' + Date.now().toString(36).substr(2, 5);
    
    // 检查分类名称是否已存在
    const categoryExists = categories.some(
      category => category.name.toLowerCase() === name.toLowerCase()
    );
    
    if (categoryExists) {
      toast.error('分类名称已存在');
      return;
    }
    
    const newCategory = {
      id: newCategoryId,
      name,
      icon,
      websites: []
    };
    
    setCategories(prevCategories => [...prevCategories, newCategory]);
    toast.success(`已添加分类: ${name}`);
  };
  
  // 删除分类
  const handleDeleteCategory = (categoryId: string) => {
    setCategories(prevCategories => 
      prevCategories.filter(category => category.id !== categoryId)
    );
   toast.success('分类已删除');
  };
  
  // 添加友情链接
  const handleAddFriendshipLink = () => {
    if (!newLinkName.trim() || !newLinkUrl.trim()) {
      toast.error('链接名称和URL不能为空');
      return;
    }
    
    if (!/^https?:\/\//i.test(newLinkUrl)) {
      toast.error('请输入有效的URL，以http://或https://开头');
      return;
    }
    
    const newLink: FriendshipLink = {
      id: `link-${Date.now()}`,
      name: newLinkName.trim(),
      url: newLinkUrl.trim()
    };
    
    setFriendshipLinks([...friendshipLinks, newLink]);
    setNewLinkName('');
    setNewLinkUrl('');
    setIsAddLinkModalOpen(false);
     toast.success(`已添加友情链接: ${newLink.name}`);
   };
   
   // 删除友情链接
   const handleDeleteFriendshipLink = (linkId: string) => {
     const linkToDelete = friendshipLinks.find(link => link.id === linkId);
     if (linkToDelete) {
       setFriendshipLinks(friendshipLinks.filter(link => link.id !== linkId));
       toast.success(`已删除友情链接: ${linkToDelete.name}`);
     }
   };
  
  // 获取收藏的网站
  const getFavoriteWebsites = () => {
    return categories.reduce((favorites, category) => {
      return [
        ...favorites,
        ...category.websites.filter(website => website.isFavorite)
      ];
    }, [] as Website[]);
  };
  
  const favoriteWebsites = getFavoriteWebsites();
  
  return (
    <div className="min-h-screen bg-gray-50 p-4 dark:bg-gray-900 md:p-6">
      {/* 顶部导航 */}
      <header className="mb-8 flex flex-col items-center justify-between gap-4 sm:flex-row">
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-3xl font-bold text-gray-800 dark:text-white">
            网址导航
          </h1>
          <p className="mt-1 text-gray-600 dark:text-gray-400">
            发现并访问您喜爱的网站
          </p>
        </motion.div>
        
        <div className="flex items-center gap-3">

            <button
              onClick={() => setIsAddModalOpen(true)}
              className="rounded-full p-2 text-gray-600 transition-colors hover:bg-blue-100 hover:text-blue-600 dark:text-gray-300 dark:hover:bg-blue-900/30 dark:hover:text-blue-400"
              aria-label="添加网站"
            >
              <i className="fa-solid fa-plus"></i>
            </button>
            
            <button
              onClick={() => setIsAddCategoryModalOpen(true)}
              className="rounded-full p-2 text-gray-600 transition-colors hover:bg-green-100 hover:text-green-600 dark:text-gray-300 dark:hover:bg-green-900/30 dark:hover:text-green-400"
              aria-label="分类管理"
            >
              <i className="fa-solid fa-folder-plus"></i>
            </button>
            
            <ThemeToggle />
          </div>
      </header>
       

      
      {/* 搜索栏 */}
      <div className="mb-8 flex justify-center">
        <SearchBar />
      </div>
      
      {/* 主要内容 */}
      <main className="max-w-6xl mx-auto">
        {/* 收藏网站部分 */}
        {favoriteWebsites.length > 0 && (
          <motion.section
            className="mb-10"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="mb-4 flex items-center text-xl font-semibold text-gray-800 dark:text-gray-200">
              <i className="fa-solid fa-star mr-2 text-yellow-400"></i>
              我的收藏
            </h2>
            
            <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
              {favoriteWebsites.map(website => {
                // 找到网站所属的分类
                const category = categories.find(cat => 
                  cat.websites.some(w => w.id === website.id)
                );
                
                return (
                  <a
                    key={website.id}
                    href={website.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group relative flex flex-col items-center justify-center rounded-xl p-4 text-center transition-all duration-300 ease-in-out bg-white shadow-md hover:shadow-lg dark:bg-gray-800"
                  >
                    <div className="flex h-12 w-12 items-center justify-center rounded-full bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-300">
                      <i className={`fa-2x ${website.icon}`}></i>
                    </div>
                    
                    <h3 className="mt-2 max-w-full truncate text-sm font-medium text-gray-800 dark:text-gray-200">
                      {website.name}
                    </h3>
                    
                    <p className="mt-1 max-w-full truncate text-xs text-gray-500 dark:text-gray-400">
                      {category?.name}
                    </p>
                    
                    <div className="absolute inset-0 rounded-xl bg-gradient-to-t from-blue-500/20 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100"></div>
                  </a>
                );
              })}
            </div>
          </motion.section>
        )}
        
        {/* 分类网站部分 */}
        <div className="space-y-8">
          {categories.map(category => (
           <CategorySection
             key={category.id}
             category={category}
             filteredWebsites={category.websites}
             onToggleFavorite={handleToggleFavorite}
             onDeleteWebsite={handleDeleteWebsite}
             onDeleteCategory={handleDeleteCategory}
           />
          ))}
        </div>
      </main>
      
      {/* 页脚 */}
       {/* 友情链接部分 */}
      <section className="mt-16 max-w-6xl mx-auto">
        <div className="bg-white rounded-xl shadow-md p-6 dark:bg-gray-800">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-bold text-gray-800 dark:text-white">
              <i className="fa-solid fa-link mr-2 text-blue-500"></i>友情链接
            </h2>
            <button
              onClick={() => setIsAddLinkModalOpen(true)}
              className="inline-flex items-center gap-2 rounded-full bg-blue-600 px-4 py-2 text-sm font-medium text-white transition-all duration-300 ease-in-out hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 dark:focus:ring-offset-gray-900"
            >
              <i className="fa-solid fa-plus"></i>
              <span>添加链接</span>
            </button>
          </div>
          
          {friendshipLinks.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
               {friendshipLinks.map(link => (
                 <div key={link.id} className="flex items-center justify-between p-3 border rounded-lg bg-gray-50 dark:bg-gray-700/50">
                   <a 
                     href={link.url} 
                     target="_blank" 
                     rel="noopener noreferrer"
                     className="text-gray-800 hover:text-blue-600 dark:text-gray-200 dark:hover:text-blue-400"
                   >
                     {link.name}
                   </a>
                 </div>
               ))}
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500 dark:text-gray-400">
              <i className="fa-solid fa-link-slash text-4xl mb-3"></i>
              <p>暂无友情链接，点击"添加链接"按钮添加</p>
            </div>
          )}
        </div>
      </section>
      
      {/* 友情链接添加模态框 */}
      <AnimatePresence mode="wait" initial={false}>
        {isAddLinkModalOpen && (
          <>
            {/* 背景遮罩 */}
            <motion.div
              className="fixed inset-0 z-40 bg-black/50 backdrop-blur-sm"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsAddLinkModalOpen(false)}
            />
            
            {/* 模态框 */}
            <motion.div
              className="fixed left-1/2 top-1/2 z-50 w-full max-w-md -translate-x-1/2 -translate-y-1/2 rounded-2xl bg-white p-6 shadow-2xl dark:bg-gray-800"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ type: 'spring', stiffness: 300, damping: 20 }}
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex justify-between items-center mb-4">
               <h2 className="text-xl font-bold text-gray-800 dark:text-white">
                 {activeLinkTab === 'add' ? '添加友情链接' : '删除友情链接'}
               </h2>
               <button
                   onClick={() => setIsAddLinkModalOpen(false)}
                   className="rounded-full p-1 text-gray-500 transition-colors hover:bg-gray-100 hover:text-gray-700 dark:hover:bg-gray-700 dark:hover:text-gray-200"
                   aria-label="Close modal"
                 >
                   <i className="fa-solid fa-times"></i>
                 </button>
               </div>
               
               {/* 标签切换 */}
               <div className="mb-6 flex rounded-lg bg-gray-100 p-1 dark:bg-gray-700">
                 <button
                   type="button"
                   onClick={() => setActiveLinkTab('add')}
                   className={`flex-1 rounded-md py-2 text-sm font-medium transition-colors ${
                     activeLinkTab === 'add'
                       ? 'bg-white text-blue-600 shadow-sm dark:bg-gray-600 dark:text-blue-400'
                       : 'text-gray-600 hover:bg-gray-200 dark:text-gray-300 dark:hover:bg-gray-600'
                   }`}
                 >
                   <i className="fa-solid fa-plus mr-1"></i> 添加链接
                 </button>
                 <button
                   type="button"
                   onClick={() => setActiveLinkTab('delete')}
                   className={`flex-1 rounded-md py-2 text-sm font-medium transition-colors ${
                     activeLinkTab === 'delete'
                       ? 'bg-white text-red-600 shadow-sm dark:bg-gray-600 dark:text-red-400'
                       : 'text-gray-600 hover:bg-gray-200 dark:text-gray-300 dark:hover:bg-gray-600'
                   }`}
                 >
                   <i className="fa-solid fa-trash mr-1"></i> 删除链接
                 </button>
               </div>
               
               <form onSubmit={(e) => {
                 e.preventDefault();
                 if (activeLinkTab === 'add') {
                   handleAddFriendshipLink();
                 } else if (activeLinkTab === 'delete' && selectedLinkId) {
                   handleDeleteFriendshipLink(selectedLinkId);
                   setSelectedLinkId('');
                 }
               }} className="space-y-4">
                 {activeLinkTab === 'add' ? (
                   <>
                     <div>
                       <label className="mb-1 block text-sm font-medium text-gray-700 dark:text-gray-300">
                         网站名称 <span className="text-red-500">*</span>
                       </label>
                       <input
                         type="text"
                         value={newLinkName}
                         onChange={(e) => setNewLinkName(e.target.value)}
                         className="w-full rounded-lg border px-3 py-2 text-gray-800 focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-200 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-200"
                         placeholder="输入网站名称"
                       />
                     </div>
                     
                     <div>
                       <label className="mb-1 block text-sm font-medium text-gray-700 dark:text-gray-300">
                         网址 <span className="text-red-500">*</span>
                       </label>
                       <input
                         type="url"
                         value={newLinkUrl}
                         onChange={(e) => setNewLinkUrl(e.target.value)}
                         className="w-full rounded-lg border px-3 py-2 text-gray-800 focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-200 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-200"
                         placeholder="https://example.com"
                       />
                       <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                         请输入完整URL，包括http://或https://
                       </p>
                     </div>
                   </>
                 ) : (
                   <div>
                     <label className="mb-1 block text-sm font-medium text-gray-700 dark:text-gray-300">
                       选择链接 <span className="text-red-500">*</span>
                     </label>
                     <select
                       value={selectedLinkId}
                       onChange={(e) => setSelectedLinkId(e.target.value)}
                       className="w-full rounded-lg border px-3 py-2 text-gray-800 focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-200 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-200"
                     >
                       <option value="">选择要删除的链接</option>
                       {friendshipLinks.map(link => (
                         <option key={link.id} value={link.id}>
                           {link.name}
                         </option>
                       ))}
                     </select>
                     
                     {selectedLinkId && (
                       <div className="mt-4 rounded-lg bg-gray-50 p-3 dark:bg-gray-700/50">
                         <p className="text-sm text-gray-500 dark:text-gray-400">
                           <i className="fa-solid fa-info-circle mr-1 text-blue-500"></i>
                           确认删除: <span className="font-medium text-gray-800 dark:text-gray-200">{
                             friendshipLinks.find(link => link.id === selectedLinkId)?.name
                           }</span>
                         </p>
                       </div>
                     )}
                   </div>
                 )}
                
                <div className="pt-2 flex space-x-3">
                  <button
                    type="button"
                    onClick={() => setIsAddLinkModalOpen(false)}
                    className="flex-1 rounded-lg border border-gray-300 px-4 py-2 text-sm font-medium text-gray-700 transition-colors hover:bg-gray-50 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-300"
                  >
                    取消
                  </button>
                  <button
                    type="submit"
                    className="flex-1 rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 dark:focus:ring-offset-gray-800"
                  >
                     {activeLinkTab === 'add' ? '添加链接' : '删除链接'}
                   </button>
                </div>
              </form>
            </motion.div>
          </>
        )}
      </AnimatePresence>
      
      {/* 页脚 */}

       
       {/* 页脚 */}
       <footer className="mt-8 text-center text-sm text-gray-500 dark:text-gray-400">
         <p>网址导航 &copy; {new Date().getFullYear()}</p>
         <p className="mt-1">保存您喜爱的网站，快速访问</p>
       </footer>
      
       {/* 添加网站模态框 */}
        <AddWebsiteModal
          isOpen={isAddModalOpen}
          onClose={() => setIsAddModalOpen(false)}
          onAddWebsite={handleAddWebsite}
          onDeleteWebsite={handleDeleteWebsite}
          categories={categories}
          categories={categories}
        />
       
        <AddCategoryModal
           isOpen={isAddCategoryModalOpen}
           onClose={() => setIsAddCategoryModalOpen(false)}
           onAddCategory={handleAddCategory}
           onDeleteCategory={handleDeleteCategory}
           categories={categories.map(c => ({id: c.id, name: c.name}))}
         />
    </div>
  );
}